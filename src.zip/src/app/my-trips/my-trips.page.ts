import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-trips',
  templateUrl: './my-trips.page.html',
  styleUrls: ['./my-trips.page.scss'],
})
export class MyTripsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
