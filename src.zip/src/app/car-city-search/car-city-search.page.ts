import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-city-search',
  templateUrl: './car-city-search.page.html',
  styleUrls: ['./car-city-search.page.scss'],
})
export class CarCitySearchPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
