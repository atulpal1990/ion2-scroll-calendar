import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-calander',
  templateUrl: './calander.component.html',
  styleUrls: ['./calander.component.scss'],
})
export class CalanderComponent implements OnInit {
  rooms = [
    {
      room_no: 1,
      adult: 2,
      child: 0,
      child_age: [
        2
      ],
      roomSize: 1
    }
  ]
  constructor(public popCtrl: PopoverController) { }

  ngOnInit(){
    
  }
  roomChange(intex){
    let json =[{
      room_no:1,
      adult:2,
      child:0,
      child_age:[0],
      roomSize:2,
    }];
    let jsons =[{
      room_no:1,
      adult:2,
      child:0,
      child_age:[0],
      roomSize:2,
    },{
      room_no:2,
      adult:1,
      child:0,
      child_age:[0],
      roomSize:1,
    }];
    let jsonss =[{
      room_no:1,
      adult:2,
      child:0,
      child_age:[0],
      roomSize:2,
    },
    {
      room_no:2,
      adult:1,
      child:0,
      child_age:[0],
      roomSize:1,
    },
    {
      room_no:3,
      adult:1,
      child:0,
      child_age:[0],
      roomSize:1,
    }]
    let number = parseInt(intex.detail.value);
    console.log(intex,number)
      if(number==1){
        this.rooms=json;
      }
      if(number==2){
        this.rooms=jsons;
      }
      if(number==3){
        this.rooms=jsonss;
      }
    
  }
  roomChangea(room){
    this.rooms = this.rooms.length+room.detail.value
    console.log(room.detail.value)

  }
  adulCount(i,index){
    console.log(i,index)
    //this.rooms[2].adult = index.detail.value
  }
  childCount(i,j){
    console.log(i,j)
    //this.rooms[2].child = i.detail.value
  }
  selectGuest(){
    return this.popCtrl.dismiss(this.rooms, 'confirm');
  }
 
}
