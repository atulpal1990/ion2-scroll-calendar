import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flight-city-search',
  templateUrl: './flight-city-search.page.html',
  styleUrls: ['./flight-city-search.page.scss'],
})
export class FlightCitySearchPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
